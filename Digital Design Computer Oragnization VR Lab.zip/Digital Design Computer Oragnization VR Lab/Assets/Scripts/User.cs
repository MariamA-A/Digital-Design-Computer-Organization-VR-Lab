using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[Serializable]
public class User
{
    public string email;
    public float ANDScore;
    public float ORScore;
    public float NOTScore;
    public float XORScore;
    public float NANDScore;
    public float HalfAdderScore;
    public float BitCompiparatorScore; 
    public string localId;
    public string idToken;
    
    public User()
    {
        email = "";
        ANDScore = 0;
        ORScore = 0;
        NOTScore = 0;
        XORScore = 0;
        NANDScore = 0;
        HalfAdderScore = 0;
        BitCompiparatorScore = 0;
        localId = "";
    }
}
