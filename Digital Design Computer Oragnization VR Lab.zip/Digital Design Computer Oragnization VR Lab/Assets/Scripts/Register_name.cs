using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;


public class Register_name : MonoBehaviour
{
    public TMP_Text usernameInput;
    public TMP_Text message;
    static public string username = "";


    // Start is called before the first frame update
    void Start()
    {
 
    }

 public void checkUser(string sceneName)
    {
        
        
        if (usernameInput.text == ""){
            message.text = "please enter your email";
        }else{
            username = usernameInput.text;
            SceneManager.LoadScene(sceneName);
            message.text = "";
        }
        
    }



}
