using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FloatingRobot : MonoBehaviour
{

public float moveSpeed = 1f;
    public float amplitude = 2f;
    public float frequency = 1f;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
     
    // Calculate the NPC's current position.
        Vector3 position = transform.position;

        // Add a sinusoidal movement to the NPC's position.
        position.y += Mathf.Sin(Time.time * frequency) * amplitude;

        // Set the NPC's position.
        transform.position = position;

    }
}
