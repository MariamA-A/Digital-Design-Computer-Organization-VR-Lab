using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManagerHalfAdder : MonoBehaviour
{

public GameObject nextButton;
public TMP_Text dialogueText;
public GameObject chip;
public GameObject HintChip;
public GameObject ChipVCCwire;
public GameObject ChipGwire;
public GameObject LED;
public GameObject switchA;
public GameObject switchB;

public GameObject XORInputA;
public GameObject XORInputB;
public GameObject XOROutput;

public GameObject ANDInputA;
public GameObject ANDInputB;
public GameObject ANDOutput;


public GameObject swWires;
public GameObject switchesButtons;
public GameObject Light;
public List<AudioSource> roboAudio;
private int roboAudioSize ;
public GameObject doneButton;
private double chiplocation;
public int count ;

public GameObject truthTable;
public GameObject Kmap;
public GameObject andChip;
public GameObject XORChip;
public GameObject circuit;

public AudioSource hitSound;








private Queue<string> sentences;
    // Start is called before the first frame update
    void Start()
    {
        
    }


    public void StartDialogue( DialogueHalfAdder dialogue){
   sentences = new Queue<string>();
    Debug.Log("start...."+dialogue.name);
    sentences.Clear();
      foreach (string sentence in dialogue.sentences)
      {
        sentences.Enqueue(sentence);
        count = 21;
        roboAudioSize = 0;
        chip.SetActive(false);
        HintChip.SetActive(false);
        ChipVCCwire.SetActive(false);
        ChipGwire.SetActive(false);
        LED.SetActive(false);

        
        swWires.SetActive(false);
        switchesButtons.SetActive(false);
        Light.SetActive(false);

        healthSystem.hintDone1 = false;
        healthSystem.hintDone2 = false;
      }
    DisplayNextSentence();
    }
     public void DisplayNextSentence(){
     if (sentences.Count == 0){
        EndDialogue();
        return;
    }
    if(count>=18){
        if(count == 18){
            chip.SetActive(true);
            HintChip.SetActive(true);
            chiplocation = chip.transform.position.x;

        }else {}
        string sentence = sentences.Dequeue();
        dialogueText.text = sentence;
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));
        roboAudio[roboAudioSize].Play();
        if(roboAudioSize>0){
        roboAudio[roboAudioSize-1].Stop();
        }
        roboAudioSize = roboAudioSize +1;
        count = count -1;
        Debug.Log("count: " +count);
    }
   else if(count==17)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 1;
    ChipVCCwire.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==16)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 1;
     ChipGwire.SetActive(true);
     Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

    else if(count==15)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
                LED.SetActive(true);

         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }

     }else if(count==14)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    switchA.SetActive(true);

    }
    }
    else if(count==13)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
       switchB.SetActive(true);

         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==12)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
   healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 3;
    swWires.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==11)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    truthTable.SetActive(true);
    Kmap.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
         else if(count==10)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;

         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
        else if(count==9)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    truthTable.SetActive(false);
    Kmap.SetActive(false);
    circuit.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==8)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    circuit.SetActive(false);
    XORChip.SetActive(true);
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    XORInputA.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

         else if(count==7)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    XORInputB.SetActive(true);
         Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

        else if(count==6)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    XOROutput.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
        else if(count==5)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
    XORChip.SetActive(false);
    andChip.SetActive(true);
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    ANDInputA.SetActive(true);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
            else if(count==4)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                   roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;

    ANDInputB.SetActive(true);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
            else if(count==3)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
        ANDOutput.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
            else if(count==2)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        truthTable.SetActive(true);
        Kmap.SetActive(true);
        andChip.SetActive(false);
                        switchesButtons.SetActive(true);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
    
      else if(count==1)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();
                nextButton.SetActive(false);
        doneButton.SetActive(true);
        roboAudioSize = roboAudioSize +1;
    count = count -1;
             
    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
            else if(count==0)
    {
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();
                    nextButton.SetActive(false);
        doneButton.SetActive(true);
        roboAudioSize = roboAudioSize +1;
    count = count -1;
        



    }
    
    }
     IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }
             Debug.Log("count: " +count);
}
    public void EndDialogue()
    {
     Debug.Log("End of conversation");
    }
}
