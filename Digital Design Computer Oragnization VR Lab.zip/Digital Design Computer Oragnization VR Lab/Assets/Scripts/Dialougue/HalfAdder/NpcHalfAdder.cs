using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcHalfAdder : MonoBehaviour
{
public DialogueHalfAdder dialogueHalfAdder;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerHalfAdder>().StartDialogue(dialogueHalfAdder);
}

 void Start()
    {
    TriggerDialogue();
    }
}
