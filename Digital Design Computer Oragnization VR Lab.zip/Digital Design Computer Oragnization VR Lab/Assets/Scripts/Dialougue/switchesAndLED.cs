using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchesAndLED : MonoBehaviour
{

public GameObject switchesON;
public GameObject switchesONEL;
public GameObject swWiresONER;
public GameObject LED;
    // Start is called before the first frame update
    void Start()
    {
            switchesON.SetActive(false);
            switchesONEL.SetActive(false);
            swWiresONER.SetActive(false);
            LED.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
