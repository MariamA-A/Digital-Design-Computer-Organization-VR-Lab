using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManager : MonoBehaviour
{

public GameObject nextButton;
 public TMP_Text dialogueText;
private Queue<string> sentences;
public GameObject ANDchip;
public GameObject ANDHintChip;
public GameObject ChipVCCwire;
public GameObject ChipGwire;
public GameObject LED;
public GameObject switchAND;
public GameObject input1;
public GameObject input2;
public GameObject output;
public GameObject swWires;
public GameObject switchesButtons;
public GameObject Light;
public GameObject truthTable;
public GameObject ANDchipInfo;
public List<AudioSource> roboAudio;
private int roboAudioSize ;
public GameObject doneButton;
public AudioSource hitSound;








private double chiplocation;

public int count ;

public GameObject circute;


    // Start is called before the first frame update
    void Start()
    {
        sentences = new Queue <string> ();
        
    }

    public void StartDialogue(Dialogue dialogue){
    sentences.Clear();
    foreach (string sentence in dialogue.sentences){
    sentences.Enqueue(sentence);
    count = 11;
    roboAudioSize = 0;
        circute.SetActive(false);
        ANDchip.SetActive(false);
        ANDHintChip.SetActive(false);
            ChipVCCwire.SetActive(false);
            ChipGwire.SetActive(false);
            LED.SetActive(false);
            switchAND.SetActive(false);
            input1.SetActive(false);
            input2.SetActive(false);
            output.SetActive(false);
            swWires.SetActive(false);
            switchesButtons.SetActive(false);
            Light.SetActive(false);
            truthTable.SetActive(false);
            ANDchipInfo.SetActive(false);

            healthSystem.hintDone1 = false;
            healthSystem.hintDone2 = false;





    }

    DisplayNextSentence();
    }

    public void DisplayNextSentence(){
    
    if (sentences.Count == 0){
        EndDialogue();
        return;
    }
    if(count>=5){
        if(count == 5){
            circute.SetActive(true);
            ANDchip.SetActive(true);
            ANDHintChip.SetActive(true);
            chiplocation = ANDchip.transform.position.x;

        }else {}
        string sentence = sentences.Dequeue();
        dialogueText.text = sentence;
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));
        roboAudio[roboAudioSize].Play();
        if(roboAudioSize>0){
        roboAudio[roboAudioSize-1].Stop();
        }
        roboAudioSize = roboAudioSize +1;
        count = count -1;
        Debug.Log("count: " +count);
    }
   else if(count==4)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    ANDchipInfo.SetActive(true);
    ChipVCCwire.SetActive(true);
    //ChipGwire.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
        hitSound.Play();
    }
    }
    else if(count==3)
            {
             if(MoveToHint.hintDone){
            count = count -1;
            MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    ANDchipInfo.SetActive(true);
    //ChipVCCwire.SetActive(true);
    ChipGwire.SetActive(true);
         Debug.Log("count: " +count);
            }
            else{
        healthSystem.life = healthSystem.life-1;
        hitSound.Play();
    }
    }
    else if(count==2)
            {
            
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
            LED.SetActive(true);
     Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

    else if(count==1)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    switchAND.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }else if(count==0)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    circute.SetActive(false);
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    input1.SetActive(true);

    }
    }
    else if(count==-1)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    input2.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
     else if(count==-2)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    output.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

         else if(count==-3)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 3;
    swWires.SetActive(true);
         Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

        else if(count==-4)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    switchesButtons.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

            else if(count==-5)
    {
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        truthTable.SetActive(true);
        nextButton.SetActive(false);
        doneButton.SetActive(true);



    }
    }


    IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }
             Debug.Log("count: " +count);

    }

    public void EndDialogue()
    {

    }
}
