using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcNot : MonoBehaviour
{
public DialogueNot dialogueNot;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerNot>().StartDialogue(dialogueNot);
}

 void Start()
    {
    TriggerDialogue();
    }
}
