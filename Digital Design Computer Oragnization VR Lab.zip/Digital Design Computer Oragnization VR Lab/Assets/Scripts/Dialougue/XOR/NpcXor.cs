using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcXor : MonoBehaviour
{
public DialogueXor dialogueXor;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerXor>().StartDialogue(dialogueXor);
}

 void Start()
    {
    TriggerDialogue();
    }
}
