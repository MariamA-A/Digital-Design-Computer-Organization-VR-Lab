using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManagerSmallBox : MonoBehaviour
{

public GameObject diaBox;
public GameObject[] otherBoxs;
public int boxs;

public List<AudioSource> allAudio;




 public TMP_Text dialogueText;
[TextArea(3,10)]
public string dialogue;
public AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {
        
    }

 public void StartDialogue(){
 diaBox.SetActive(true);
 for (int i = 0; i < boxs; i++)
    {
    otherBoxs[i].SetActive(false);
    }
    DisplayNextSentence();
    }

    public void DisplayNextSentence()
    {
    string sentence = dialogue;
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
    StopAllAudio();
    audioSource.Play();
    }

      IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }

    }

    void StopAllAudio() {
    foreach(AudioSource audioS in allAudio){
        audioS.Stop();
    }
    }
    public void EndDialogue()
    {

    }
}
