using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManagerComparator : MonoBehaviour
{

public GameObject nextButton;
public TMP_Text dialogueText;
public GameObject Comparatorchip;
public GameObject ComparatorHintChip;
public GameObject ChipVCCwire;
public GameObject ChipGwire;
public GameObject LED;
public GameObject switchComparatorA;
public GameObject switchComparatorB;
public GameObject NOTinputA;
public GameObject NOTinputB;
public GameObject NOToutputA;
public GameObject BtoAND;
public GameObject AlessB;
public GameObject NotAToAND;
public GameObject NotBToAND;
public GameObject AToAND;
public GameObject BToAND;
public GameObject NotAndOutputToOR;
public GameObject AndOutputToOR;
public GameObject AEqaualB;
public GameObject NotBToANDbig;
public GameObject AToANDbig;
public GameObject ABiggerB;
public GameObject swWires;
public GameObject switchesButtons;
public GameObject Light;
public List<AudioSource> roboAudio;
private int roboAudioSize ;
public GameObject doneButton;
private double chiplocation;
public int count ;

public GameObject truthTable;
public GameObject notChip;
public GameObject andChip;
public GameObject orChip;
public GameObject kLess;
public GameObject kEqaual;
public GameObject kBigger;

public AudioSource hitSound;








private Queue<string> sentences;
    // Start is called before the first frame update
    void Start()
    {
        
    }


    public void StartDialogue( DialogueComparator dialogue){
   sentences = new Queue<string>();
    Debug.Log("start...."+dialogue.name);
    sentences.Clear();
      foreach (string sentence in dialogue.sentences)
      {
        sentences.Enqueue(sentence);
        count = 33;
        roboAudioSize = 0;
        Comparatorchip.SetActive(false);
        ComparatorHintChip.SetActive(false);
        ChipVCCwire.SetActive(false);
        ChipGwire.SetActive(false);
        LED.SetActive(false);

        
        swWires.SetActive(false);
        switchesButtons.SetActive(false);
        Light.SetActive(false);
        truthTable.SetActive(false);

        healthSystem.hintDone1 = false;
        healthSystem.hintDone2 = false;
      }
    DisplayNextSentence();
    }
     public void DisplayNextSentence(){
     if (sentences.Count == 0){
        EndDialogue();
        return;
    }
    if(count>=30){
        if(count == 30){
            Comparatorchip.SetActive(true);
            ComparatorHintChip.SetActive(true);
            chiplocation = Comparatorchip.transform.position.x;

        }else {}
        string sentence = sentences.Dequeue();
        dialogueText.text = sentence;
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));
        roboAudio[roboAudioSize].Play();
        if(roboAudioSize>0){
        roboAudio[roboAudioSize-1].Stop();
        }
        roboAudioSize = roboAudioSize +1;
        count = count -1;
        Debug.Log("count: " +count);
    }
   else if(count==29)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 2;
    ChipVCCwire.SetActive(true);
    //ChipGwire.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
     else if(count==28)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 2;
     ChipGwire.SetActive(true);
     Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

    else if(count==27)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;

                LED.SetActive(true);

         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }

     }else if(count==26)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    switchComparatorA.SetActive(true);

    }
    }
    else if(count==25)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
       switchComparatorB.SetActive(true);

         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
     else if(count==24)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    notChip.SetActive(true);
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NOTinputA.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

         else if(count==23)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NOTinputB.SetActive(true);
         Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

        else if(count==22)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    notChip.SetActive(false);
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 3;
    swWires.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
        else if(count==21)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    
    ///add conditions truth table .SetActive(true);
    truthTable.SetActive(true);
    kBigger.SetActive(true);
    kEqaual.SetActive(true);
    kLess.SetActive(true);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
            else if(count==20)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                   roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    ///explaning the first condition A less than B
     kBigger.SetActive(false);
    kEqaual.SetActive(false);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
            else if(count==19)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        truthTable.SetActive(false);
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
        kLess.SetActive(false);
        notChip.SetActive(true);
        andChip.SetActive(true);
    NOToutputA.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
            else if(count==18)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        notChip.SetActive(false);
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    BtoAND.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
            else if(count==17)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    AlessB.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==16)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    andChip.SetActive(false);
    BtoAND.SetActive(false);
    truthTable.SetActive(true);
    kBigger.SetActive(true);
    kEqaual.SetActive(true);
    kLess.SetActive(true);

    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==15)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    
    kBigger.SetActive(false);
    kEqaual.SetActive(true);
    kLess.SetActive(false);
    
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==14)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
     truthTable.SetActive(false);
     kEqaual.SetActive(false);
     notChip.SetActive(true);
     andChip.SetActive(true);
     MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NotAToAND.SetActive(true);
    
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==13)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NotBToAND.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==12)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
         notChip.SetActive(false);
         MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    AToAND.SetActive(true);
    
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
           else if(count==11)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    BToAND.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
    else if(count==10)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
                orChip.SetActive(true);
                MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NotAndOutputToOR.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }

     else if(count==9)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    AndOutputToOR.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
    else if(count==8)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        MoveToHint.hintDone = false;
        andChip.SetActive(false);
        MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    AEqaualB.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
    else if(count==7)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    orChip.SetActive(false);
    truthTable.SetActive(true);
    kBigger.SetActive(true);
    kEqaual.SetActive(true);
    kLess.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
     else if(count==6)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
           roboAudio[roboAudioSize].Play();
           roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    truthTable.SetActive(true);
    kBigger.SetActive(true);
    kEqaual.SetActive(false);
    kLess.SetActive(false);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
      else if(count==5)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
           roboAudio[roboAudioSize].Play();
           roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
     MoveToHint.hintDone = false;
     truthTable.SetActive(false);
     kBigger.SetActive(false);
     notChip.SetActive(true);
     andChip.SetActive(true);
     MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NotBToANDbig.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
      else if(count==4)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
           roboAudio[roboAudioSize].Play();
           roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
     MoveToHint.hintDone = false;
     MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
          notChip.SetActive(false);

    AToANDbig.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
      else if(count==3)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
     MoveToHint.hintDone = false;
     MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    ABiggerB.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
      else if(count==2)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
     andChip.SetActive(false);
     truthTable.SetActive(true);
    kBigger.SetActive(true);
    kEqaual.SetActive(true);
    kLess.SetActive(true);
    switchesButtons.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
      else if(count==1)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
            roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
             nextButton.SetActive(false);
        doneButton.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                hitSound.Play();

    }
    }
            else if(count==0)
    {
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        nextButton.SetActive(false);
        doneButton.SetActive(true);



    }
    
    }
     IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }
             Debug.Log("count: " +count);
}
    public void EndDialogue()
    {
     Debug.Log("End of conversation");
    }
}
