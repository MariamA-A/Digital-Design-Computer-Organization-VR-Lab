using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcComparator : MonoBehaviour
{
public DialogueComparator dialogueComparator;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerComparator>().StartDialogue(dialogueComparator);
}

 void Start()
    {
    TriggerDialogue();
    }
}
