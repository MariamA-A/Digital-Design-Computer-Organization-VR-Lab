using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManagerTools : MonoBehaviour
{
public GameObject diaBox;

 public TMP_Text dialogueText;
[TextArea(3,10)]
public string dialogue;
public AudioSource audioSource;
    // Start is called before the first frame update
    void Start()
    {

        StartDialogue(dialogue);
    }

    public void StartDialogue(string dialogue){
    
    DisplayNextSentence();
    }

    public void DisplayNextSentence()
    {
    string sentence = dialogue;
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
    audioSource.Play();
    }

      IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }

    }

    public void EndDialogue()
    {

    }
}
