using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueManagerNand : MonoBehaviour
{

public GameObject nextButton;
public TMP_Text dialogueText;
public GameObject Nandchip;
public GameObject NandHintChip;
public GameObject ChipVCCwire;
public GameObject ChipGwire;
public GameObject LED;
public GameObject switchNand;
public GameObject input1;
public GameObject input2;
public GameObject output;
public GameObject swWires;
public GameObject switchesButtons;
public GameObject Light;
public GameObject truthTable;
public GameObject NandChipInfo;
public List<AudioSource> roboAudio;
private int roboAudioSize ;
public GameObject doneButton;
private double chiplocation;
public int count ;
public GameObject circute;
public AudioSource hitSound;






private Queue<string> sentences;
    // Start is called before the first frame update
    void Start()
    {
        
    }


    public void StartDialogue( DialogueNand dialogue){
   sentences = new Queue<string>();
    Debug.Log("start...."+dialogue.name);
    sentences.Clear();
      foreach (string sentence in dialogue.sentences)
      {
        sentences.Enqueue(sentence);
        count = 13;
        roboAudioSize = 0;
        circute.SetActive(false);
        Nandchip.SetActive(false);
        NandHintChip.SetActive(false);
        ChipVCCwire.SetActive(false);
        ChipGwire.SetActive(false);
        LED.SetActive(false);
        switchNand.SetActive(false);
        input1.SetActive(false);
        input2.SetActive(false);
        output.SetActive(false);
        swWires.SetActive(false);
        switchesButtons.SetActive(false);
        Light.SetActive(false);
        truthTable.SetActive(false);
        NandChipInfo.SetActive(false);

        healthSystem.hintDone1 = false;
        healthSystem.hintDone2 = false;
      }
    DisplayNextSentence();
    }
     public void DisplayNextSentence(){
     if (sentences.Count == 0){
        EndDialogue();
        return;
    }
    if(count>=10){
        if(count == 10){
            circute.SetActive(true);
            Nandchip.SetActive(true);
            NandHintChip.SetActive(true);
            chiplocation = Nandchip.transform.position.x;

        }else {}
        string sentence = sentences.Dequeue();
        dialogueText.text = sentence;
        StopAllCoroutines();
        StartCoroutine(TypeSentence(sentence));
        roboAudio[roboAudioSize].Play();
        if(roboAudioSize>0){
        roboAudio[roboAudioSize-1].Stop();
        }
        roboAudioSize = roboAudioSize +1;
        count = count -1;
        Debug.Log("count: " +count);
    }
   else if(count==9)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NandChipInfo.SetActive(true);
    ChipVCCwire.SetActive(true);
    //ChipGwire.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
    else if(count==8)
            {
        if(MoveToHint.hintDone){

    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    NandChipInfo.SetActive(true);
    //ChipVCCwire.SetActive(true);
    ChipGwire.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==7)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
            LED.SetActive(true);
     Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

    else if(count==6)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    switchNand.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }

     }else if(count==5)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    circute.SetActive(false);
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    input1.SetActive(true);

    }
    }
    else if(count==4)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    input2.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }
     else if(count==3)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 0;
    output.SetActive(true);
         Debug.Log("count: " +count);


    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

         else if(count==2)
            {
        if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    MoveToHint.hintDone = false;
    healthSystem.hintDone1 = false;
    healthSystem.hintDone2 = false;
    healthSystem.wireNum = 3;
    swWires.SetActive(true);
         Debug.Log("count: " +count);

    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

        else if(count==1)
    {
     if(MoveToHint.hintDone){
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
    switchesButtons.SetActive(true);
    }else{
        healthSystem.life = healthSystem.life-1;
                        hitSound.Play();

    }
    }

            else if(count==0)
    {
    string sentence = sentences.Dequeue();
    dialogueText.text = sentence;
    StopAllCoroutines();
    StartCoroutine(TypeSentence(sentence));
            roboAudio[roboAudioSize].Play();
                    roboAudio[roboAudioSize-1].Stop();

        roboAudioSize = roboAudioSize +1;
    count = count -1;
        truthTable.SetActive(true);
        nextButton.SetActive(false);
        doneButton.SetActive(true);



    }
    
    }
     IEnumerator TypeSentence (string sentence){

        

        dialogueText.text = "";
        foreach (char letter in sentence.ToCharArray())
        {
            dialogueText.text+= letter;
            yield return null;
        }
             Debug.Log("count: " +count);
}
    public void EndDialogue()
    {
     Debug.Log("End of conversation");
    }
}
