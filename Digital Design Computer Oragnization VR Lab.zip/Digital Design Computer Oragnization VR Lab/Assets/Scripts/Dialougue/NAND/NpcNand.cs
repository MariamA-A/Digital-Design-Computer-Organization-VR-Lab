using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcNand : MonoBehaviour
{
public DialogueNand dialogueNand;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerNand>().StartDialogue(dialogueNand);
}

 void Start()
    {
    TriggerDialogue();
    }
}
