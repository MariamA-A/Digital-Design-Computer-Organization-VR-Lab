using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NpcOr : MonoBehaviour
{
public DialogueOr dialogueOr;

public void TriggerDialogue(){
FindObjectOfType<DialogueManagerOr>().StartDialogue(dialogueOr);
}

 void Start()
    {
    TriggerDialogue();
    }
}
