using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using Proyecto26;

public class LoginPassword : MonoBehaviour

{

public TMP_Text passwordInput;
public TMP_Text message;
private string idToken;
public static string localId;
private string AuthKey = "AIzaSyCMnroEmCXTgEkYBKUTUWK4d_wnvDvXpN0";
public static User player;


    // Start is called before the first frame update
    void Start()
    {
      
    }

    public void SignInUserButton()
    {
        SignInUser(LoginUser.currentUser, passwordInput.text);
    }

     private void SignInUser(string email, string password)
    {
        string userData = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\",\"returnSecureToken\":true}";
        RestClient.Post<SignResponse>("https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=" + AuthKey, userData).Then(
            response =>
            {
            player = new User ();
            player.email = response.email;
            player.ANDScore = response.ANDScore;
            player.ORScore = response.ORScore;
            player.NOTScore = response.NOTScore;
            player.XORScore = response.XORScore;
            player.NANDScore = response.NANDScore;
            player.HalfAdderScore = response.HalfAdderScore;
            player.BitCompiparatorScore = response.BitCompiparatorScore;
            player.localId = response.localId;
            player.idToken = response.idToken;
            message.text = "";
            SceneManager.LoadScene("WelcomePage");
            }).Catch(error =>
        {
        message.text = "ERROR: Email or password is not correct";
            Debug.Log(error);
        });
    }
}
