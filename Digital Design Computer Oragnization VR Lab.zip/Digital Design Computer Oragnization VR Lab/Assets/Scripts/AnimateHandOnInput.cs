using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class AnimateHandOnInput : MonoBehaviour
{

public InputActionProperty pinchAnimationonAction;
public Animator handAnimator;
public InputActionProperty gripAnimationonAction;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
       float triggerValue = pinchAnimationonAction.action.ReadValue<float>();

       handAnimator.SetFloat("Trigger", triggerValue);

       float gripValue = gripAnimationonAction.action.ReadValue<float>();

        handAnimator.SetFloat("Grip", gripValue);
    }
}
