using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class healthSystem : MonoBehaviour
{

public GameObject[] hearts;
public static int life =3;
 public static bool hintDone1;
 public static bool hintDone2;
 public static int wireNum;

    // Start is called before the first frame update
    void Start()
    {
  
    }

    // Update is called once per frame
    void Update()
    {
        if( life<1){

        Destroy(hearts[0].gameObject);
        SceneManager.LoadScene("GameOver");
        life = 3;

        } else if (life < 2){
                Destroy(hearts[1].gameObject);


        }else if (life < 3){
                Destroy(hearts[2].gameObject);

        }
    }

    public void TakeDamage(int damage){

    life -= damage;

    }
}
