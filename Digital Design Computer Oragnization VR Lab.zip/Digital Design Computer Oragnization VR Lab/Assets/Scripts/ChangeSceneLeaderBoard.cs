using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class ChangeSceneLeaderBoard : MonoBehaviour
{

public void setlabname (string labName){
Timer.labname = labName;
}
public void LoadScene (string sceneName){

SceneManager.LoadScene(sceneName);
}

}
