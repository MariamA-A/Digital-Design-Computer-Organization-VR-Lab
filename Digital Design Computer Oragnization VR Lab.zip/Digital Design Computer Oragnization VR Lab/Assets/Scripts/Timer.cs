using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using Proyecto26;



public class Timer : MonoBehaviour
{

private string databaseURL = "https://yourDatabase.firebaseio.com/users";
public TextMeshProUGUI timerText;
public bool running = false;
public string labName;
static public string labname;
User user;


public float currentTime;

static public float doneTime = 0;

 ArrayList leaderboard;


    // Start is called before the first frame update
    void Start()
    {
    labname =labName;
        
    }

    // Update is called once per frame
    void Update()
    {
    if (running){
        currentTime = currentTime +=Time.deltaTime;
        timerText.text = currentTime.ToString();
        }
        else{
        doneTime = currentTime;
        PostToDatabase();
        SceneManager.LoadScene("Done");
        }
    }


    public void Stop(){
        running = false;
        healthSystem.life = 3;
        
    }

    private void PostToDatabase()
    {
        
        

         if (labname == "lab01AND")
        {
            if (LoginPassword.player.ANDScore < doneTime){
                LoginPassword.player.ANDScore = doneTime;
            }
        }else if (labname == "lab01OR"){
            if (LoginPassword.player.ORScore < doneTime){
                LoginPassword.player.ORScore = doneTime;
            }
        }else if (labname == "lab01NOT"){
            if (LoginPassword.player.NOTScore < doneTime){
                LoginPassword.player.NOTScore = doneTime;
            }
        }else if (labname == "lab01XOR"){
            if (LoginPassword.player.XORScore < doneTime){
                LoginPassword.player.XORScore = doneTime;
                }
        }else if (labname == "lab01NAND"){
            if (LoginPassword.player.NANDScore < doneTime){
                LoginPassword.player.NANDScore = doneTime;
                }
        }else if (labname == "HalfAdder"){
            if (LoginPassword.player.HalfAdderScore < doneTime){
                LoginPassword.player.HalfAdderScore = doneTime;
                }
        }else if (labname == "1bitComparator"){
        if (LoginPassword.player.BitCompiparatorScore < doneTime){
            LoginPassword.player.BitCompiparatorScore = doneTime;
            }
        }

        RestClient.Put(databaseURL + "/" +  LoginPassword.player.localId + ".json?auth=" +  LoginPassword.player.idToken, LoginPassword.player);
    }
    
}
