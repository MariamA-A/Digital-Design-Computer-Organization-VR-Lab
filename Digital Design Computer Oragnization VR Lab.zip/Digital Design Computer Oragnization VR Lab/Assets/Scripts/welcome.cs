using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
public class welcome : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }
    public TMP_Text textfield;

    // Update is called once per frame
public void setText()
    {

        textfield.text += LoginUser.currentUser;
		
    
    
    }
}
