using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;


public class typing : MonoBehaviour
{
    public TMP_Text textfield;
	string userText;
    
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    public void setText(string mytext)
    {
    if (mytext == "back" ){
    userText = userText.Remove(userText.Length -1, 1);
    textfield.text = userText;
    }else{
        userText += mytext;
		textfield.text = userText;
    }
    
    }
}
