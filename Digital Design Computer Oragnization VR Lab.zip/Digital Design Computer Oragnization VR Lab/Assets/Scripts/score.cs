using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class score : MonoBehaviour
{
 public TMP_Text scoreText;
    // Start is called before the first frame update
    void Start()
    {
        scoreText.text = LoginUser.currentUser + " your time is: "+ Timer.doneTime;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
