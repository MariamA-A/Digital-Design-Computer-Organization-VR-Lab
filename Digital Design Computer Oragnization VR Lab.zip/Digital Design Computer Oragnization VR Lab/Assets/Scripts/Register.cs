using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using UnityEngine.Serialization;
using Proyecto26;



public class Register : MonoBehaviour
{
    public TMP_Text passwordInput;
    public TMP_Text errorText;

        private string databaseURL = "https://yourDatabase.firebaseio.com/users";
        private string AuthKey = "youDatabaseAuthKey";
        public static string localId;
        private string getLocalId;
        private string idToken;



        User user = new User();
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public void OnRegister()
    {
         SignUpUser(Register_name.username, passwordInput.text);
    }


    private void SignUpUser(string email, string password)
    {
        string userData = "{\"email\":\"" + email + "\",\"password\":\"" + password + "\",\"returnSecureToken\":true}";
        RestClient.Post<SignResponse>("https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=" + AuthKey, userData).Then(
            response =>
            {
                idToken = response.idToken;
                localId = response.localId;
                PostToDatabase(true, email, localId);
                errorText.text = "Registration done, please go back and login!";
                
            }).Catch(error =>
        {
         Debug.Log("POST ERROR");
            Debug.Log(error);
            errorText.text = "ERROR: Cannot register! Email already registered OR weak password";
        });
    }

    private void PostToDatabase(bool emptyScore, string email, string localId)
    {
        User user = new User(); 
        user.email = email;
        user.localId = localId;
        user.idToken = idToken;

         if (emptyScore)
        {
            user.ANDScore = 0;
            user.ORScore = 0;
            user.NOTScore = 0;
            user.XORScore = 0;
            user.NANDScore = 0;
            user.HalfAdderScore = 0;
            user.BitCompiparatorScore = 0;
        }

        RestClient.Put(databaseURL + "/" + localId + ".json?auth=" + idToken, user);

    }

}
