using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BackSpace : MonoBehaviour
{
    public TMP_Text textfield;
	string userText;
    string backText;
    // Start is called before the first frame update
    void Start()
    {
        
    }

   
    public void back()
    {
    userText = textfield.text;
	backText = userText.Remove(userText.Length -1, 1);
    textfield.text = "embty";
    }
}
