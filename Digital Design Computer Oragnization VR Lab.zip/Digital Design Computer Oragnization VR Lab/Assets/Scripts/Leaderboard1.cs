using System;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Linq;
using System.Collections.Generic;
using FullSerializer;
using Proyecto26;


public class Leaderboard1 : MonoBehaviour
{

 public TMP_Text textArea;
 public string labName ="";
 ArrayList leaderboardText;
 public static fsSerializer serializer = new fsSerializer();
  List<Score> scores = new List<Score>();
  
  private string databaseURL = "https://vr-digital-design-lab-c7ba1-default-rtdb.firebaseio.com/users";
  //private string AuthKey = "AIzaSyCMnroEmCXTgEkYBKUTUWK4d_wnvDvXpN0";

    // Start is called before the first frame update
    void Start()
    {
    labName = Timer.labname;
     textArea.text += "Name\t\t\t\t\t\t\t\tTime\n";
    GetScore();
    }



     void  GetScore(){
        RestClient.Get(databaseURL + ".json?auth=" + LoginPassword.player.idToken).Then(response =>
       //RestClient.Get(databaseURL + ".json?auth=eyJhbGciOiJSUzI1NiIsImtpZCI6IjdjZjdmODcyNzA5MWU0Yzc3YWE5OTVkYjYwNzQzYjdkZDJiYjcwYjUiLCJ0eXAiOiJKV1QifQ.eyJpc3MiOiJodHRwczovL3NlY3VyZXRva2VuLmdvb2dsZS5jb20vdnItZGlnaXRhbC1kZXNpZ24tbGFiIiwiYXVkIjoidnItZGlnaXRhbC1kZXNpZ24tbGFiIiwiYXV0aF90aW1lIjoxNzA1MjQ5MTc3LCJ1c2VyX2lkIjoiWFZ6ampsNTZZZ1ZaVTBsS0hEODdOSXhXQjVUMiIsInN1YiI6IlhWempqbDU2WWdWWlUwbEtIRDg3Tkl4V0I1VDIiLCJpYXQiOjE3MDUyNDkxNzcsImV4cCI6MTcwNTI1Mjc3NywiZW1haWwiOiIxMjNAdS5hZSIsImVtYWlsX3ZlcmlmaWVkIjpmYWxzZSwiZmlyZWJhc2UiOnsiaWRlbnRpdGllcyI6eyJlbWFpbCI6WyIxMjNAdS5hZSJdfSwic2lnbl9pbl9wcm92aWRlciI6InBhc3N3b3JkIn19.GIrEI81aY6N6zlTrjlXizOb0r8loQgvCC4tcPORCFypnfgfwMyZCimXhM1ZEHmp4rcsa-7B9i0ar4GuZ590h2ujSR80hUrQbygrjUVCm3brmjn0kybU2w-YzeRkqPi_cH9oBNp1SWZRpeuhmTEb8ftiecCx94n5L_ZtOaBJEuzCsOri9ujF6lvUiSJjJ584J4fFOCRHMqLCOrLnBRQ134PL12_tThSknDXWuEX3XXVyus6ltOgsRXHFAtfTi2WR1mBtLfMitxgpj-k6ZUeH-863mu6iFF-wNu6CxgrcJg8d8ALacoFHLBWj6_4dJ-50tbWZqATIuU2mtItKsi42D4g").Then(response =>
       {
            Debug.Log("GetScore");
            fsData userData = fsJsonParser.Parse(response.Text);
            Dictionary<string, User> users = null;
            serializer.TryDeserialize(userData, ref users);
            foreach (var user in users.Values)
          {
            double score =0;
            string name = user.email;
            if(labName == "lab01AND"){
             score = user.ANDScore;
            }else if (labName == "lab01OR"){
             score = user.ORScore;
            }else if (labName == "lab01XOR"){
             score = user.XORScore;
            }else if (labName == "lab01NAND"){
             score = user.NANDScore;
            }else if (labName == "lab01NOT"){
             score = user.NOTScore;
            }else if (labName == "1bitComparator"){
             score = user.BitCompiparatorScore;
            }else if (labName == "HalfAdder"){
             score = user.HalfAdderScore;
            }
            scores.Add(new Score(name, score));
            Debug.Log("Count: "+scores.Count);
                    //Debug.Log(scores[0].myName + scores[0].myScore);
            }
            Debug.Log("Count out of loop: "+scores.Count);
            scores.Sort((a, b) =>(int) (a.myScore - b.myScore));
             for (int i = 0; i < scores.Count; i++)
        {
        if(scores[i].myScore!=0.0){
            textArea.text += scores[i].myName+"\t\t\t\t\t\t"+scores[i].myScore+"\n";
            }
          }
        }).Catch(error =>
        {
            Debug.Log(error);
        });

    }

    }
class Score {

    public string myName { get; set; }
    public double myScore { get; set; }

    public Score(string name, double score) {
        myName = name;
        myScore = score;
    }
}
