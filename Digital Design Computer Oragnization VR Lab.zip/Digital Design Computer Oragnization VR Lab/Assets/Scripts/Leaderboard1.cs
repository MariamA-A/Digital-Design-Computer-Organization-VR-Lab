using System;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;
using System.Linq;
using System.Collections.Generic;
using FullSerializer;
using Proyecto26;


public class Leaderboard1 : MonoBehaviour
{

 public TMP_Text textArea;
 public string labName ="";
 ArrayList leaderboardText;
 public static fsSerializer serializer = new fsSerializer();
  List<Score> scores = new List<Score>();
  
  private string databaseURL = "https://yourDatabase.firebaseio.com/users";

    // Start is called before the first frame update
    void Start()
    {
    labName = Timer.labname;
     textArea.text += "Name\t\t\t\t\t\t\t\tTime\n";
    GetScore();
    }



     void  GetScore(){
        RestClient.Get(databaseURL + ".json?auth=" + LoginPassword.player.idToken).Then(response =>
       {
            Debug.Log("GetScore");
            fsData userData = fsJsonParser.Parse(response.Text);
            Dictionary<string, User> users = null;
            serializer.TryDeserialize(userData, ref users);
            foreach (var user in users.Values)
          {
            double score =0;
            string name = user.email;
            if(labName == "lab01AND"){
             score = user.ANDScore;
            }else if (labName == "lab01OR"){
             score = user.ORScore;
            }else if (labName == "lab01XOR"){
             score = user.XORScore;
            }else if (labName == "lab01NAND"){
             score = user.NANDScore;
            }else if (labName == "lab01NOT"){
             score = user.NOTScore;
            }else if (labName == "1bitComparator"){
             score = user.BitCompiparatorScore;
            }else if (labName == "HalfAdder"){
             score = user.HalfAdderScore;
            }
            scores.Add(new Score(name, score));
            Debug.Log("Count: "+scores.Count);
                    //Debug.Log(scores[0].myName + scores[0].myScore);
            }
            Debug.Log("Count out of loop: "+scores.Count);
            scores.Sort((a, b) =>(int) (a.myScore - b.myScore));
             for (int i = 0; i < scores.Count; i++)
        {
        if(scores[i].myScore!=0.0){
            textArea.text += scores[i].myName+"\t\t\t\t\t\t"+scores[i].myScore+"\n";
            }
          }
        }).Catch(error =>
        {
            Debug.Log(error);
        });

    }

    }
class Score {

    public string myName { get; set; }
    public double myScore { get; set; }

    public Score(string name, double score) {
        myName = name;
        myScore = score;
    }
}
