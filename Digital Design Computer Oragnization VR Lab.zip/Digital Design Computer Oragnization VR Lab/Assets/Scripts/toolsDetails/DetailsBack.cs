using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class DetailsBack : MonoBehaviour
{

public GameObject tool;
public GameObject zoomOut;
public GameObject toolDetails;
public GameObject robo;
public GameObject roboZoomOut;
public GameObject diaBox;
public GameObject button;
public List <GameObject> buttons;


public GameObject oldCanves;
public float speed;
    // Start is called before the first frame update
    void Start()
    {
        
    }

 public void ZoomObjectOut(){
    oldCanves.SetActive(true);
    StartCoroutine(MoveMyObject (tool,zoomOut, speed));
    StartCoroutine(MoveMyObject (robo,roboZoomOut, speed));
    
    diaBox.SetActive(false);
    toolDetails.SetActive(false);
    button.SetActive(false);

    for (int index = 0; index < buttons.Count; index++)
{
    buttons[index].SetActive(true);
}

    }

    IEnumerator MoveMyObject(GameObject gameobjA, GameObject gameobjB, float speedTranslation)
    {
        while (gameobjA.transform.position != gameobjB.transform.position)
        {
            gameobjA.transform.position = Vector3.MoveTowards(gameobjA.transform.position, gameobjB.transform.position, speedTranslation * Time.deltaTime);
            yield return null;
        }
    }
}
