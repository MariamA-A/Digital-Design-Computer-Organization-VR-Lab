using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class Details : MonoBehaviour
{

public GameObject tool;
public GameObject zoomIn;
public GameObject toolDetails;
public string info;
public GameObject robo;
public GameObject roboZoom;
public GameObject diaBox;
public GameObject backbutton;
public List <GameObject> buttons;

public GameObject oldCanves;
public float speed;

    // Start is called before the first frame update
    void Start()
    {
    diaBox.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ZoomObject(){
    oldCanves.SetActive(false);
    backbutton.SetActive(true);
    StartCoroutine(MoveMyObject (tool,zoomIn, speed));
    StartCoroutine(MoveMyObject (robo,roboZoom, speed));
    
for (int index = 0; index < buttons.Count; index++)
{
    buttons[index].SetActive(false);
}

    diaBox.SetActive(true);
    toolDetails.SetActive(true);

    }

    IEnumerator MoveMyObject(GameObject gameobjA, GameObject gameobjB, float speedTranslation)
    {
        while (gameobjA.transform.position != gameobjB.transform.position)
        {
            gameobjA.transform.position = Vector3.MoveTowards(gameobjA.transform.position, gameobjB.transform.position, speedTranslation * Time.deltaTime);
            yield return null;
        }
    }
}
