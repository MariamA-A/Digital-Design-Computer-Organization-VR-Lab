using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class SignResponse
{
   public string email;
    public float ANDScore;
    public float ORScore;
    public float NOTScore;
    public float XORScore;
    public float NANDScore;
    public float HalfAdderScore;
    public float BitCompiparatorScore; 
    public string localId;
    public string idToken;
}
