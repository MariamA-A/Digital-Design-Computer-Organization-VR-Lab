using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class MoveWireToHint : MonoBehaviour
{

public GameObject hint1;
public GameObject hint2;
public GameObject otherWire;

private  Vector3 startPos;
private  Vector3 finalPos;
private Vector3 resetPosition;
public static bool hintDone;
private Rigidbody rb;


 public bool bIsOnTheMove = false;

    // Start is called before the first frame update
    void Start()
    {
        resetPosition = this.transform.position;
        hintDone = false;
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
      CheckMoving();
        if(!bIsOnTheMove)
        {
         if(Mathf.Abs(this.transform.position.x - hint1.transform.position.x)<=0.1f&&
            Mathf.Abs(this.transform.position.y - hint1.transform.position.y)<=0.1f&&
            Mathf.Abs(this.transform.position.z - hint1.transform.position.z)<=0.1f&& !(hint1.transform.position == otherWire.transform.position))
            {
                this.transform.position = new Vector3(hint1.transform.position.x, hint1.transform.position.y, hint1.transform.position.z);            
                this.transform.eulerAngles = new Vector3 (0,0,0);
                hint1.SetActive(false);
                gameObject.GetComponent<XRGrabInteractable>().enabled = false;
                GetComponent<Rigidbody>().isKinematic = true;
                hintDone = true;          
            }else if(Mathf.Abs(this.transform.position.x - hint2.transform.position.x)<=0.1f&&
            Mathf.Abs(this.transform.position.y - hint2.transform.position.y)<=0.1f&&
            Mathf.Abs(this.transform.position.z - hint2.transform.position.z)<=0.1f&& !(hint2.transform.position == otherWire.transform.position))
            {
                this.transform.position = new Vector3(hint2.transform.position.x, hint2.transform.position.y, hint2.transform.position.z);           
                this.transform.eulerAngles = new Vector3 (0,0,0);            
                hint2.SetActive(false);
                gameObject.GetComponent<XRGrabInteractable>().enabled = false;
                GetComponent<Rigidbody>().isKinematic = true;
                hintDone = true;          
            }else
            {
                this.transform.position = new Vector3(resetPosition.x, resetPosition.y, resetPosition.z);
                this.transform.eulerAngles = new Vector3 (-90,0,0);
                hint1.SetActive(true);
                hintDone = false;
             }
        }
    }


    private IEnumerator  CheckMoving()
    {
        startPos = this.transform.position;
        yield return new WaitForSeconds(1f);
        finalPos = this.transform.position;

        if( startPos.x != finalPos.x || startPos.y != finalPos.y
            || startPos.z != finalPos.z){
          bIsOnTheMove = true;}
    }

}
