using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchL : MonoBehaviour
{

public GameObject switchesOFF;
        public GameObject switchesON;
        public GameObject switchButtonL;
        public GameObject switchButtonR;
        public GameObject LED;
        public string chip;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PressSwitch()
    {

    if (chip == "AND"){
     if (switchesON.activeSelf)
     {
        switchesON.SetActive(false);
        switchesOFF.SetActive(false);
        switchButtonR.SetActive(true);
        switchButtonL.SetActive(false);

        LED.SetActive(false);
     }

     else if (!switchButtonL.activeSelf && switchButtonR.activeSelf)
     {
        switchButtonR.SetActive(false);
        switchButtonL.SetActive(false);
        switchesOFF.SetActive(false);
        switchesON.SetActive(true);
        LED.SetActive(true);
     }
     else if (switchesOFF.activeSelf)
     {
        switchesOFF.SetActive(false);
        switchesON.SetActive(false);
        switchButtonL.SetActive(true);
        switchButtonR.SetActive(false);
        LED.SetActive(false);
     }
     else if (switchButtonL.activeSelf && !switchButtonR.activeSelf)
     {
        switchButtonL.SetActive(false);
        switchButtonR.SetActive(false);
        switchesON.SetActive(false);
        switchesOFF.SetActive(true);
        LED.SetActive(false);
     }
     } else if(chip == "OR"){
     if (switchesON.activeSelf)
     {
        switchesON.SetActive(false);
        switchesOFF.SetActive(false);
        switchButtonR.SetActive(true);
        switchButtonL.SetActive(false);

        LED.SetActive(true);
     }

     else if (!switchButtonL.activeSelf && switchButtonR.activeSelf)
     {
        switchButtonR.SetActive(false);
        switchButtonL.SetActive(false);
        switchesOFF.SetActive(false);
        switchesON.SetActive(true);
        LED.SetActive(true);
     }
     else if (switchesOFF.activeSelf)
     {
        switchesOFF.SetActive(false);
        switchesON.SetActive(false);
        switchButtonL.SetActive(true);
        switchButtonR.SetActive(false);
        LED.SetActive(true);
     }
     else if (switchButtonL.activeSelf && !switchButtonR.activeSelf)
     {
        switchButtonL.SetActive(false);
        switchButtonR.SetActive(false);
        switchesON.SetActive(false);
        switchesOFF.SetActive(true);
        LED.SetActive(false);
     
     }
      } else if(chip == "XOR"){
     if (switchesON.activeSelf)
     {
        switchesON.SetActive(false);
        switchesOFF.SetActive(false);
        switchButtonR.SetActive(true);
        switchButtonL.SetActive(false);

        LED.SetActive(true);
     }

     else if (!switchButtonL.activeSelf && switchButtonR.activeSelf)
     {
        switchButtonR.SetActive(false);
        switchButtonL.SetActive(false);
        switchesOFF.SetActive(false);
        switchesON.SetActive(true);
        LED.SetActive(false);
     }
     else if (switchesOFF.activeSelf)
     {
        switchesOFF.SetActive(false);
        switchesON.SetActive(false);
        switchButtonL.SetActive(true);
        switchButtonR.SetActive(false);
        LED.SetActive(true);
     }
     else if (switchButtonL.activeSelf && !switchButtonR.activeSelf)
     {
        switchButtonL.SetActive(false);
        switchButtonR.SetActive(false);
        switchesON.SetActive(false);
        switchesOFF.SetActive(true);
        LED.SetActive(false);
     }
     }else if(chip == "NAND"){
     if (switchesON.activeSelf)
     {
        switchesON.SetActive(false);
        switchesOFF.SetActive(false);
        switchButtonR.SetActive(true);
        switchButtonL.SetActive(false);

        LED.SetActive(true);
     }

     else if (!switchButtonL.activeSelf && switchButtonR.activeSelf)
     {
        switchButtonR.SetActive(false);
        switchButtonL.SetActive(false);
        switchesOFF.SetActive(false);
        switchesON.SetActive(true);
        LED.SetActive(false);
     }
     else if (switchesOFF.activeSelf)
     {
        switchesOFF.SetActive(false);
        switchesON.SetActive(false);
        switchButtonL.SetActive(true);
        switchButtonR.SetActive(false);
        LED.SetActive(true);
     }
     else if (switchButtonL.activeSelf && !switchButtonR.activeSelf)
     {
        switchButtonL.SetActive(false);
        switchButtonR.SetActive(false);
        switchesON.SetActive(false);
        switchesOFF.SetActive(true);
        LED.SetActive(true);
     }
    }
    }
}
