using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switchesForChips : MonoBehaviour
{

  public GameObject switchesON;
  public GameObject switchesOFF;
  public GameObject switch1;
  public GameObject switch2;
  public GameObject LED;
  public string chip ;
  public int switchNum;

    // Start is called before the first frame update
    void Start()
    {
        
    }

     public void PressSwitch()
    {
      //  if (chip.Equals("AND")){

            if(switchNum ==1){
                if(switch1.activeSelf&& switch2.activeSelf){
                    switch1.SetActive(false);
                    switch2.SetActive(true);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(false);
                    LED.SetActive(false);
                }
                if(!switch1.activeSelf&& switch2.activeSelf){
                    switch1.SetActive(false);
                    switch2.SetActive(false);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(true);
                    LED.SetActive(true);

                }
                if(!switch1.activeSelf&& !switch2.activeSelf){
                    switch1.SetActive(true);
                    switch2.SetActive(false);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(false);
                    LED.SetActive(false);

                }
                if(switch1.activeSelf&& !switch2.activeSelf){
                    switch1.SetActive(false);
                    switch2.SetActive(false);
                    switchesOFF.SetActive(true);
                    switchesON.SetActive(false);
                    LED.SetActive(false);

                }
            }
            if(switchNum ==2){
                if(switch2.activeSelf&& switch1.activeSelf){
                    switch2.SetActive(false);
                    switch1.SetActive(true);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(false);
                    LED.SetActive(false);

                }
                if(!switch2.activeSelf&& switch1.activeSelf){
                    switch2.SetActive(false);
                    switch1.SetActive(false);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(true);
                    LED.SetActive(true);

                }
                if(!switch2.activeSelf&& !switch2.activeSelf){
                    switch2.SetActive(true);
                    switch1.SetActive(false);
                    switchesOFF.SetActive(false);
                    switchesON.SetActive(false);
                    LED.SetActive(false);
                }
                if(switch2.activeSelf&& !switch1.activeSelf){
                    switch2.SetActive(false);
                    switch1.SetActive(false);
                    switchesOFF.SetActive(true);
                    switchesON.SetActive(false);
                    LED.SetActive(false);

                }
            }
        }
   // }

}
