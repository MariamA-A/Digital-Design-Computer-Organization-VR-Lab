using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class switches : MonoBehaviour
{

        public GameObject switchesOFF;
        public GameObject switchesON;
        public GameObject switch1;
        public GameObject switch2;
        public GameObject LED;
        public static bool switch1On;
        public static bool switch2On;
        public int switchNum;
        public static bool buttonsActive;


    // Start is called before the first frame update
    void Start()
    {
     switch1On = false;
     switch2On = false;


    }

    // Update is called once per frame
    void Update()
    {
        
    }


    public void PressSwitch()
    {
    buttonsActive = true;
    if(buttonsActive){

        if (switchNum == 1 && !switch1On)
        {

            if(switch2)
            {
                switch2.SetActive(false);
                switch1.SetActive(false);
                switchesOFF.SetActive(false);
                switchesON.SetActive(true);
                // LED ON
                LED.SetActive(true);
            }
            else if(!switch2)
            {
                switchesOFF.SetActive(false);

                switch1.SetActive(true);
            }
        }
        else if(switchNum == 1 && switch1On)
        {
            if(switch2)
            {
                switchesON.SetActive(false);
                switch2.SetActive(true);
                // LED OFF
                LED.SetActive(false);
            }
            else if(!switch2)
            {
                switch1.SetActive(false);
                switchesOFF.SetActive(true);
            }
        }

        else if (switchNum == 2 && !switch2On){
            if(switch1)
            {
                switch1.SetActive(false);
                switchesON.SetActive(true);
                // LED ON
                LED.SetActive(true);
            }
            else if(!switch1)
            {
                switchesOFF.SetActive(false);
                switch2.SetActive(true);
            }
        }
        else if(switchNum == 1 && switch2On)
        {
            if(switch1)
            {
                switchesON.SetActive(false);
                switch1.SetActive(true);
                // LED OFF
                LED.SetActive(false);

            }
            else if(!switch1)
            {
                switch2.SetActive(false);
                switchesOFF.SetActive(true);
            }
    
        }
        }
    }
}