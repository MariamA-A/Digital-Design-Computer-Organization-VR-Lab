using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class halfAdderA : MonoBehaviour
{

        public GameObject switchButtonAON;
        public GameObject switchButtonAOFF;

        public GameObject switchButtonBON;
        public GameObject switchButtonBOFF;

        public GameObject RedLED;
        public GameObject YellowLED;


        public string chip;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PressSwitch()
    {

   

     if (!switchButtonAON.activeSelf && switchButtonBON.activeSelf)
     {
        switchButtonAON.SetActive(true);
        switchButtonAOFF.SetActive(false);

        RedLED.SetActive(true);
        YellowLED.SetActive(false);
     }
     else if (switchButtonAON.activeSelf && switchButtonBON.activeSelf)
     {
        switchButtonAON.SetActive(false);
        switchButtonAOFF.SetActive(true);

        RedLED.SetActive(false);
        YellowLED.SetActive(true);
        }
        else if (switchButtonAON.activeSelf && !switchButtonBON.activeSelf)
     {
        switchButtonAON.SetActive(false);
        switchButtonAOFF.SetActive(true);

        RedLED.SetActive(false);
        YellowLED.SetActive(false);
        }
     
     else if (!switchButtonAON.activeSelf && !switchButtonBON.activeSelf)
     {
        switchButtonAON.SetActive(true);
        switchButtonAOFF.SetActive(false);

        RedLED.SetActive(false);
        YellowLED.SetActive(true);
        }
     
    }
}
