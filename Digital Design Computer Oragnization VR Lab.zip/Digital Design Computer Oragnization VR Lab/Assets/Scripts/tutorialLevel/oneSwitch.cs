using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class oneSwitch : MonoBehaviour
{

public GameObject switchOFF;
public GameObject switchON;
 public GameObject LED;
        public string chip;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PressSwitch(){
        if(chip == "NOT"){
            if(switchOFF.activeSelf){
                switchOFF.SetActive(false);
                switchON.SetActive(true);

                LED.SetActive(false);
            }
            else if(switchON.activeSelf){
                switchOFF.SetActive(true);
                switchON.SetActive(false);

                LED.SetActive(true);
            }
        }
    }
}
