using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class MoveWire : MonoBehaviour
{
public GameObject hint1;
public GameObject hint2;

public GameObject wire;
 private  Vector3 startPos;
private  Vector3 finalPos;
private Vector3 resetPosition;
private Rigidbody rb;
//private bool bIsOnTheMove = false;
private Collider myCollider;
public string color1;
public string color2;

    void Start()
    {
    
        resetPosition = wire.transform.position;
        MoveToHint.hintDone = false;
        myCollider = GetComponent<Collider>();
      //  StartCoroutine( CheckMoving() ); //right way to call coroutine.
    }

    void Update()
    {
     if(healthSystem.hintDone1 && healthSystem.hintDone2 && healthSystem.wireNum == 0){
      MoveToHint.hintDone = true;
      }
      else{
       MoveToHint.hintDone = false;
      }
    }
private void OnTriggerEnter(Collider hint){
      MoveToHint.hintDone = false;
 if(hint.tag == color1){
     Debug.Log("hit hint1");
     if(!healthSystem.hintDone1){
        myCollider.isTrigger = false;
        Vector3 hintPos = hint1.transform.position;
        hint1.SetActive(false);
        hint1.SetActive(false);
        wire.GetComponent<XRGrabInteractable>().enabled = false;
        wire.GetComponent<Rigidbody>().isKinematic = true;
        GetComponentInParent<Transform>().position = hintPos;            
        wire.transform.eulerAngles = new Vector3 (0,0,0);                
        healthSystem.hintDone1 = true;
        Debug.Log("hint1 move Done!");
     }else{
        GetComponentInParent<Transform>().position = new Vector3(resetPosition.x, resetPosition.y, resetPosition.z);
        wire.transform.eulerAngles = new Vector3 (-90,0,0);
     }
 }else if ( hint.tag == color2){
     Debug.Log("hit hint2");
     if(!healthSystem.hintDone2){
        myCollider.isTrigger = false;
        Vector3 hintPos = hint2.transform.position;
        hint2.SetActive(false);
        wire.GetComponent<XRGrabInteractable>().enabled = false;
        wire.GetComponent<Rigidbody>().isKinematic = true;
        GetComponentInParent<Transform>().position = hintPos;            
        wire.transform.eulerAngles = new Vector3 (0,0,0);  
        healthSystem.hintDone2 = true;
        Debug.Log("hint2 move Done!");
     }else{
        GetComponentInParent<Transform>().position = new Vector3(resetPosition.x, resetPosition.y, resetPosition.z);
        wire.transform.eulerAngles = new Vector3 (-90,0,0);
     }
 }

 if(healthSystem.hintDone1 && healthSystem.hintDone2 && healthSystem.wireNum == 0){
      MoveToHint.hintDone = true;
 }
 else if (healthSystem.hintDone1 && healthSystem.hintDone2 && healthSystem.wireNum != 0){
 Debug.Log("wire"+ healthSystem.wireNum);
      healthSystem.wireNum = healthSystem.wireNum -1;
      healthSystem.hintDone1 = false;
      healthSystem.hintDone2 = false;
      MoveToHint.hintDone = false;
 }
}
// private IEnumerator  CheckMoving()
  //  {
   //     startPos = this.transform.position;
   //     yield return new WaitForSeconds(1f);
    //    finalPos = this.transform.position;

    //    if( startPos.x != finalPos.x || startPos.y != finalPos.y
    //        || startPos.z != finalPos.z){
    //      bIsOnTheMove = true;}
   // }
}
