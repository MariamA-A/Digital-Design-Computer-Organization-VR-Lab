using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bitComparatorB : MonoBehaviour
{

        public GameObject switchButtonAON;
        public GameObject switchButtonAOFF;

        public GameObject switchButtonBON;
        public GameObject switchButtonBOFF;

        public GameObject RedLED;
        public GameObject GreenLED;
        public GameObject YellowLED;


        public string chip;



    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void PressSwitch()
    {

   

     if (!switchButtonAON.activeSelf && switchButtonBON.activeSelf)
     {
        switchButtonBON.SetActive(false);
        switchButtonBOFF.SetActive(true);

        RedLED.SetActive(true);
        GreenLED.SetActive(false);
        YellowLED.SetActive(false);
     }
     else if (switchButtonAON.activeSelf && switchButtonBON.activeSelf)
     {
        switchButtonBON.SetActive(false);
        switchButtonBOFF.SetActive(true);

        RedLED.SetActive(false);
        GreenLED.SetActive(false);
        YellowLED.SetActive(true);
        }
        else if (switchButtonAON.activeSelf && !switchButtonBON.activeSelf)
     {
        switchButtonBON.SetActive(true);
        switchButtonBOFF.SetActive(false);

        RedLED.SetActive(true);
        GreenLED.SetActive(false);
        YellowLED.SetActive(false);
        }
     
     else if (!switchButtonAON.activeSelf && !switchButtonBON.activeSelf)
     {
        switchButtonBON.SetActive(true);
        switchButtonBOFF.SetActive(false);

        RedLED.SetActive(false);
        GreenLED.SetActive(true);
        YellowLED.SetActive(false);
        }
     
    }
}
