using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit;

public class MoveToHint : MonoBehaviour

{


public GameObject hint;
private  Vector3 startPos;
private  Vector3 finalPos;
private Vector3 resetPosition;
public static bool hintDone;
private Rigidbody rb;
public string objName;
//private bool moved;


 public bool bIsOnTheMove = false;

    // Start is called before the first frame update
    void Start()
    {
        resetPosition = this.transform.position;
        hintDone = false;
        rb = GetComponent<Rigidbody>();
        //moved = false;
    }

    // Update is called once per frame
    void Update()
    {
    CheckMoving();
        // StartCoroutine(CheckMoving());
        if(!bIsOnTheMove)
        {
         
        if(Mathf.Abs(this.transform.position.x - hint.transform.position.x)<=0.1f&&
            Mathf.Abs(this.transform.position.y - hint.transform.position.y)<=0.1f&&
            Mathf.Abs(this.transform.position.z - hint.transform.position.z)<=0.1f)
            {
                     
                this.transform.position = new Vector3(hint.transform.position.x, hint.transform.position.y, hint.transform.position.z);
                            if(objName == "ANDchip"){
                            this.transform.eulerAngles = new Vector3 (-90,0,0);
                            }else if(objName == "LED"){
                            this.transform.eulerAngles = new Vector3 (0,0,90);
                            }else if(objName == "switchA"){
                            this.transform.eulerAngles = new Vector3 (0,90,0);
                            }else if(objName == "switch"){
                            this.transform.eulerAngles = new Vector3 (0,-90,0);
                            }else if(objName == "switchB"){
                            this.transform.eulerAngles = new Vector3 (0,90,0);
                            }else{
                this.transform.eulerAngles = new Vector3 (0,0,0);
                }
                hint.SetActive(false);
           gameObject.GetComponent<XRGrabInteractable>().enabled = false;
            GetComponent<Rigidbody>().isKinematic = true;
                        hintDone = true;                
            }else{
         //  if((this.transform.position.x !=resetPosition.x)&&(this.transform.position.y !=resetPosition.y)&&(this.transform.position.z !=resetPosition.z)){
          //     healthSystem.life =healthSystem.life-1;
          //  }

                  //healthSystem.life = healthSystem.life-1;

            this.transform.position = new Vector3(resetPosition.x, resetPosition.y, resetPosition.z);
                            this.transform.eulerAngles = new Vector3 (-90,0,0);
                                            hint.SetActive(true);
                                                    hintDone = false;

           //Debug.Log("moved: " +moved);
                  //   if(moved){
                 //    Debug.Log("-1");
               // healthSystem.life =-1;
              //  moved =false;
           // }                                          
                                         //   Debug.Log("life:"+healthSystem.life);
                              
                                    }

        }
    }
    

    private IEnumerator  CheckMoving()
    {
        startPos = this.transform.position;
        yield return new WaitForSeconds(3f);
        finalPos = this.transform.position;

        if( startPos.x != finalPos.x || startPos.y != finalPos.y
            || startPos.z != finalPos.z)
        {
                bIsOnTheMove = true;
              //  moved = true;
              //  Debug.Log("moved: " +moved);

}else{
     bIsOnTheMove = false;
}
   }
}
